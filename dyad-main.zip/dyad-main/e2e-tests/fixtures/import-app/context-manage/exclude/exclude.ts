// exclude.ts: this file is not in any of the globs
