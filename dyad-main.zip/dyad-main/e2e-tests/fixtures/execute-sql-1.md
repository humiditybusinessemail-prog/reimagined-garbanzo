Example SQL

<dyad-execute-sql description="create_users_table">
CREATE TABLE users (id serial primary key);
</dyad-execute-sql>

Done.
